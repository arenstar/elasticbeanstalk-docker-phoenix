# docker-phoenix

Simple Dockerfile for Phoenix Applications.

Supports both MySQL and PostgreSQL applications
